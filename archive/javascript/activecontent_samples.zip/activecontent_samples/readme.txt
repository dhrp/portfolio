Active Content Embedding Sample Files
=====================================

Read the following before using the files within this archive.

1. This archive contains files that belong to the article at: 
http://www.adobe.com/devnet/activecontent/articles/devletter.html


2. This sample archive contains six files:

* AC_RunActiveContent.js: This is the file you use for the workaround for Flash and Shockwave content described in "External JavaScript Solution 2: For Multiple Occurrences of Embedded Content."

* AC_ActiveX.js: Use this file for the fix described in "Solution for Other Active Content Types."

* SampleActiveContent.html: This file provides an example of the code you would use in your HTML page when using the AC_RunActiveContent.js and AC_ActiveX.js files.

* button1.fla: This file is the source file for the SWF. 

* button1.swf: This file is the SWF that is embedded in the page. 

* readme.txt: This is the file you are reading, which describes the ZIP file's contents.
